<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabTestResult extends Model
{
    use HasFactory;
    protected $fillable = [
        'patient_lab_test_id', 'lab_test_parameter_id', 'result'
    ];

    public function patientLabTest()
    {
        return $this->belongsTo(PatientLabTest::class);
    }

    public function labTestParameter()
    {
        return $this->belongsTo(LabTestParameter::class);
    }
}
