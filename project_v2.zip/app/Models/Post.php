<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;
    protected $table = 'posts';
    protected $fillable = ['title', 'body', 'patient_id', 'is_anonymous', 'image'];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }
    
}
