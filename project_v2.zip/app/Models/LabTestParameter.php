<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LabTestParameter extends Model
{
    use HasFactory;

    protected $fillable = [
        'lab_test_id',
        'parameter_name',
        'unit',
        'normal_range',
    ];

    public function labTest()
    {
        return $this->belongsTo(LabTest::class);
    }

    public function results()
    {
        return $this->hasMany(LabTestResult::class, 'lab_test_parameter_id');
    }
}