<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    use HasFactory;
    protected $table = 'patients';
    protected $fillable = [
        'first_name', 'last_name', 'date_of_birth', 'gender',
        'phone_number', 'address', 'notes', 'image', 'active_state', 'user_id'
    ];
    
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }

    public function medicalRecord()
    {
        return $this->hasOne(MedicalRecord::class);
    }

    public function patientLabTests()
    {
        return $this->hasMany(PatientLabTest::class);
    }
    
    public function labTests()
    {
        return $this->belongsToMany(LabTest::class, 'patient_lab_tests', 'patient_id', 'lab_test_id');
    }
    public function prescriptions()
    {
        return $this->hasMany(Prescription::class);
    }
}
