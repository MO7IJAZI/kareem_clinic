<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabTechnician extends Model
{
    use HasFactory;
    protected $table = 'lab_technicians';
    protected $fillable = [
        'user_id', 'image', 'address', 'lab_name', 'phone_number'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}