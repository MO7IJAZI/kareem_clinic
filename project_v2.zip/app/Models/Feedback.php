<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    use HasFactory;
    protected $table = 'feedbacks';
    protected $fillable = ['title', 'content', 'patient_id', 'rating', 'is_viewed'];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }
}
