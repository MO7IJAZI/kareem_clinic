<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PatientLabTest extends Model
{
    use HasFactory;
    protected $table = 'patient_lab_tests';
    protected $fillable = ['patient_id', 'lab_test_id', 'test_date', 'doctor_id', 'status'];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function labTest()
    {
        return $this->belongsTo(LabTest::class);
    }

    public function results()
    {
        return $this->hasMany(LabTestResult::class);
    }
    public function doctor()
    {
        return $this->belongsTo(Doctor::class);
    }
}
