<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function login(Request $request) {
        $credentials = $request->only('email', 'password');
        
        $request->validate([
            'password' => 'required|min:8',
        ]);

        if (auth()->attempt($credentials)) {
            $user = auth()->user();
            $token = $user->createToken($user->role)->plainTextToken;
            switch($user->role) {
                case 'manager':
                    return response()->json([
                        'role' => 'manager',
                        'token' => $token,
                    ]);
                case 'patient':
                    return response()->json([
                        'role' => 'patient',
                        'token' => $token,
                    ]);
                case 'secretary':
                    return response()->json([
                        'role' => 'secretary',
                        'token' => $token,
                    ]);
                case 'doctor':
                    return response()->json([
                        'role' => 'doctor',
                        'token' => $token,
                    ]);
                case 'lab_tech':
                    return response()->json([
                        'role' => 'lab_tech',
                        'token' => $token,
                    ]);
                default:
                    return response()->json(['message' => 'Invalid credentials!'], 401);
            }
        } else {
            return response()->json(['message' => 'Invalid credentials!'], 401);
        }
    }
}
