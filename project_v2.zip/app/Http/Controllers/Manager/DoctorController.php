<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use App\Models\Specialization;
use App\Http\Resources\Manager\DoctorResource;
class DoctorController extends Controller
{
    public function index()
    {
        $doctors = Doctor::all();
        return DoctorResource::collection($doctors);
    }
    public function destroy(Doctor $doctor)
    {
        $doctor->delete();
        return response()->json([
            'message' => 'Doctor deleted successfully',
        ]);
    }
    public function addDoctorToSpecialization(Doctor $doctor, Specialization $specialization)
    {
        $doctor->specialization_id = $specialization->id;
        $doctor->save();
        return response()->json([
            'message' => 'Doctor added to specialization successfully',
        ]);
    }   
    public function removeDoctorFromSpecialization(Doctor $doctor, Specialization $specialization)
    {
        $doctor->specialization_id = null;
        $doctor->save();
        return response()->json([
            'message' => 'Doctor removed from specialization successfully',
        ]);
    } 
}
