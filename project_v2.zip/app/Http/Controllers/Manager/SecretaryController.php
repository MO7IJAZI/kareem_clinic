<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Secretary;
use App\Http\Resources\Manager\SecretaryResource;
class SecretaryController extends Controller
{
    public function index()
    {
        $secretaries = Secretary::all();
        return SecretaryResource::collection($secretaries);
    }
}
