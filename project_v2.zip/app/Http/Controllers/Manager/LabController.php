<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LabTest;
use App\Models\LabTechnician;
use App\Http\Resources\Manager\LabTechinicanResource;
class LabController extends Controller
{
    public function index()
    {
        $labTests = LabTest::all();
        return response()->json($labTests);
    }
    public function displayLabTechnicians()
    {
        $labTechnicians = LabTechnician::with('user')->get();
        return LabTechinicanResource::collection($labTechnicians);
    }
    public function store(Request $request)
    {
        $request->validate([
            'test_name' => 'required|string|max:255',
            'description' => 'required|string|max:255',
            'price' => 'required|numeric',
        ]);
        $labTest = LabTest::create($request->all());
        return response()->json([
            'message' => 'Lab test added successfully',
            'lab_test' => $labTest,
        ]);
    }
    
    public function update(Request $request, LabTest $labTest)
    {
        $labTestData = $request->all();
        $labTestData = array_filter($labTestData, function($value) {
            return !is_null($value);
        });
        $labTest->update($labTestData);
        return response()->json([
            'message' => 'Lab test updated successfully',
        ]);
    }   
    public function destroy(LabTest $labTest)
    {
        $labTest->delete();
        return response()->json([
            'message' => 'Lab test deleted successfully',
        ]);
    }
}
