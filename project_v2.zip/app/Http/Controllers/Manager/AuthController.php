<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Secretary;
use App\Models\Doctor;
use App\Models\LabTechnician;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
class AuthController extends Controller
{
    public function registerNewSecretary(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
        ]);
        DB::beginTransaction();
        $user = User::create([
            'username' => $request->first_name . ' ' . $request->last_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'secretary',
        ]);
        Secretary::create([
            'user_id' => $user->id,
        ]);
        DB::commit();
        return response()->json([
            'message' => 'Secretary Account Created Successfully',
            'password' => $request->password,
        ]);
    }

    public function registerNewDoctor(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'specialization_id' => 'required|exists:specializations,id',
            'phone_number' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'date_of_birth' => 'required|date',
            'gender' => 'required|string|max:255',
        ]);
        DB::beginTransaction();

        $user = User::create([
            'username' => $request->first_name . ' ' . $request->last_name, 
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'doctor',
        ]);
        
        Doctor::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'phone_number' => $request->phone_number,
            'user_id' => $user->id,
            'specialization_id' => $request->specialization_id,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'active_state' => true,
            'image' => null,
        ]);
        DB::commit();
        return response()->json([
            'message' => 'Doctor Account Created Successfully',
            'password' => $request->password,
        ]);
    }

    public function registerNewLabTechnician(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
        ]);
        DB::beginTransaction();
        $user = User::create([
            'username' => $request->first_name . ' ' . $request->last_name, 
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'lab_tech',
        ]);
        LabTechnician::create([
            'user_id' => $user->id,
        ]);
        DB::commit();
        return response()->json([
            'message' => 'Lab Technician Account Created Successfully',
            'password' => $request->password,
        ]);
    }
}
