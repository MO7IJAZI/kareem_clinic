<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use App\Models\Feedback;
use Illuminate\Http\Request;
use Carbon\Carbon;
class FeedbackController extends Controller
{
    public function getAllFeedbacks()
    {
        $feedbacks = Feedback::with('patient')->get()->map(function ($feedback) {
            return [
                'id' => $feedback->id,
                'title' => $feedback->title,
                'content' => $feedback->content,
                'rating' => $feedback->rating,
                'patient_name' => $feedback->patient->user->username,
                'created_at' => Carbon::parse($feedback->created_at)->format('Y-m-d H:i:s'),
            ];
        });
        return response()->json($feedbacks);
    }
}
