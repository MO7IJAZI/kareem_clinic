<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Specialization;
class SpecializationController extends Controller
{
    public function index()
    {
        $specializations = Specialization::all();
        return response()->json($specializations);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:255',
        ]);
        Specialization::create([
            'name' => $request->name,
            'description' => $request->description,
        ]);
        return response()->json([
            'message' => 'Specialization added successfully',
        ]);
    }

    public function update(Request $request, Specialization $specialization)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);
        
        $specializationData = array_filter($request->all(), function($value) {
            return !is_null($value);
        });
        $specialization->update($specializationData);
        return response()->json([
            'message' => 'Specialization information updated successfully',
        ]);     
    }

    public function destroy(Specialization $specialization)
    {
        
        $specialization->delete();
        return response()->json([
            'message' => 'Specialization deleted successfully',
        ]);
    }
      
    public function addLabTechnicianToSpecialization(Request $request, Specialization $specialization)
    {
        $request->validate([
            'lab_technician_id' => 'required|exists:lab_technicians,id',
        ]);
        $specialization->labTechnicians()->attach($request->lab_technician_id);
        return response()->json([
            'message' => 'Lab Technician added to specialization successfully',
        ]);
    }   
    public function removeLabTechnicianFromSpecialization(Request $request, Specialization $specialization)     
    {
        $request->validate([
            'lab_technician_id' => 'required|exists:lab_technicians,id',
        ]);
        $specialization->labTechnicians()->detach($request->lab_technician_id);
        return response()->json([
            'message' => 'Lab Technician removed from specialization successfully',
        ]);
    }
}
