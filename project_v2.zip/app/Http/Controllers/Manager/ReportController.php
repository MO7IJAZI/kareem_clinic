<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\PatientLabTest;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function dailyReport(Request $request)
    {
        // Default to today if no date provided
        $date = $request->input('date', Carbon::today()->toDateString());
        
        // Count patients created on the specified date
        $patientCount = Patient::whereDate('created_at', $date)->count();
        
        // Count lab tests conducted on the specified date
        $labTestCount = PatientLabTest::whereDate('test_date', $date)->count();
        
        return response()->json([
            'date' => $date,
            'patient_count' => $patientCount,
            'lab_test_count' => $labTestCount
        ]);
    }
    
    public function monthlyReport(Request $request)
    {
        // Default to current month if none provided
        $month = $request->input('month', Carbon::now()->month);
        $year = $request->input('year', Carbon::now()->year);
        
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();
        
        // Count patients registered in the specified month
        $patientCount = Patient::whereBetween('created_at', [$startDate, $endDate])->count();
        
        // Count lab tests conducted in the specified month
        $labTestCount = PatientLabTest::whereBetween('test_date', [$startDate, $endDate])->count();
        
        // Optional: Get daily breakdown for the month
        $dailyStats = [];
        $currentDate = $startDate->copy();
        
        while ($currentDate->lte($endDate)) {
            $dateString = $currentDate->toDateString();
            $dailyStats[] = [
                'date' => $dateString,
                'patient_count' => Patient::whereDate('created_at', $dateString)->count(),
                'lab_test_count' => PatientLabTest::whereDate('test_date', $dateString)->count()
            ];
            $currentDate->addDay();
        }
        
        return response()->json([
            'month' => $month,
            'year' => $year,
            'patient_count' => $patientCount,
            'lab_test_count' => $labTestCount,
            'daily_breakdown' => $dailyStats
        ]);
    }
}