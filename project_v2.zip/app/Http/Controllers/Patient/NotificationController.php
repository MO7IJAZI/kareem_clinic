<?php

namespace App\Http\Controllers\Patient;

use App\Models\Notification;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Patient\NotificationResource;
class NotificationController extends Controller
{
    public function index()
    {
        $notifications = Notification::where('patient_id', Auth::user()->patient->id)
            ->where('read', false)
            ->orderBy('created_at', 'desc')
            ->get();
        return NotificationResource::collection($notifications);
    }

    public function markAsRead(Notification $notification)
    {
        $this->authorize('markAsRead', $notification);

        $notification->update(['read' => true]);
        return response()->json(['message' => 'Notification marked as read']);
    }
    public function readNotifications()
    {
        $notifications = Notification::where('patient_id', Auth::user()->patient->id)
            ->where('read', true)
            ->get();
        return NotificationResource::collection($notifications);
    }
    public function destroy(Notification $notification)
    {
        $this->authorize('delete', $notification);

        $notification->delete();
        return response()->json(['message' => 'Notification deleted']);
    }
}
