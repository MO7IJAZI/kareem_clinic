<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use App\Models\Post;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function index(Post $post)
    {
        $comments = Comment::where('post_id', $post->id)->get()->map(function($comment){
            return [
                'id' => $comment->id,
                'body' => $comment->body,
                'is_anonymous' => $comment->is_anonymous,
                'created_at' => Carbon::parse($comment->created_at)->format('Y-m-d H:i:s')
            ];
        });
        return $comments;
    }
    public function store(Request $request, Post $post)
    {
        $request->validate([
            'body' => 'required|string',
            'is_anonymous' => 'required|boolean',
        ]);

        $comment = Comment::create($request->all() + ['user_id' => auth()->user()->id, 'post_id' => $post->id]);
        return response()->json([
            'message' => 'Comment created successfully',
            'comment' => $comment->body,
            'is_anonymous' => $comment->is_anonymous,
            'created_at' => Carbon::parse($comment->created_at)->format('Y-m-d H:i:s')
        ]);
    }
    public function show(Comment $comment)
    {
        return response()->json([
            'comment' => $comment
        ]);
    }
    public function update(Request $request, Comment $comment)
    {
        $this->authorize('update', $comment);
        
        $commentData = array_filter($request->all(), function($value) {
            return !is_null($value);
        });

        $comment->update($commentData);
        return response()->json([
            'message' => 'Comment updated successfully',
            'comment' => $comment
        ]);
    }
    public function destroy(Comment $comment)
    {
        $this->authorize('delete', $comment);

        $comment->delete();
        return response()->json([
            'message' => 'Comment deleted successfully',
        ]);
    }
}
