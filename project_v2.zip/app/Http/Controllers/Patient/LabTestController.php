<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Patient\LabTestResultResource;
use App\Models\Patient;

class LabTestController extends Controller
{
    public function index()
    {
        $patient = Patient::where('user_id', auth()->user()->id)->first();
        $patientWithLabTests = Patient::with(
            'patientLabTests.labTest', 
            'patientLabTests.labTest.parameters', 
            'patientLabTests.labTestResults'
        )->find($patient->id);
        
        return new LabTestResultResource($patientWithLabTests);
    }
}
