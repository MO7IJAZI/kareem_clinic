<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Patient\ProfileResource;
use App\Services\ImageUploadService;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    protected $imageService;
    public function __construct(ImageUploadService $imageService)
    {
        $this->imageService = $imageService;
    }

    public function profile() {
        $patient = auth()->user()->patient;
        return new ProfileResource($patient);
    }

    public function updateProfile(Request $request) {
        $user = auth()->user();
        $patient = auth()->user()->patient;
        $patientData = $request->all();

        /**
         * removes any key/value pair where the value is null. 
         * This prevents overwriting existing data with null.
         */
        $patientData = array_filter($patientData, function($value) {
            return !is_null($value);
        });
        
        if ($request->hasFile('image')) {
            $patientData['image'] = $this->imageService->uploadImage($request, 'image', 'patients');
        }

        $user->update($patientData);
        $patient->update($patientData);
        
        return new ProfileResource($patient);
    }
}
