<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Http\Requests\PatientRegistrationRequest;
use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\User;
use App\Services\ImageUploadService;
use Illuminate\Support\Facades\DB;
class AuthController extends Controller
{
    protected $imageService;
    public function __construct(ImageUploadService $imageService) {
        $this->imageService = $imageService;
    }

    public function register(PatientRegistrationRequest $request){

        $validatedData = $request->validated();
        $imagePath = $this->imageService->uploadImage($request, 'image', 'patients');
        
        $user = User::create([
            'username' => $validatedData['first_name'] . ' ' . $validatedData['last_name'],
            'password' => bcrypt($validatedData['password']),
            'email' => $validatedData['email'],
            'role' => 'patient',
        ]);
        
        $token = $user->createToken($user->role)->plainTextToken;

        unset($validatedData['image']);
        
        $patientData = $validatedData + [
            'user_id' => $user->id,
            'image' => $imagePath
        ];
        DB::beginTransaction();
        $patient = Patient::create($patientData);
        MedicalRecord::create([
            'patient_id' => $patient->id,
        ]);
        DB::commit();

        return response()->json([
            'message' => 'Patient registered successfully!',
            'token' => $token
        ], 200);
    }
    public function logout() {
        if (auth()->check()) {
            auth()->user()->tokens()->delete(); // Revoke tokens for API logout
        }

        return response()->json([
            'message' => 'Patient logged out successfully!'
        ]);
    }
}
