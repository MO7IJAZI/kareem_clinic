<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Patient\AppointmentResource;
use App\Http\Resources\Patient\AvailableAppointmentResource;
use App\Models\Appointment;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    public function myAppointments() {
        return AppointmentResource::collection(auth()->user()->patient->appointments);
    }

    public function getAvailableAppointments(Request $request) {

        $request->validate([
            'date' => 'required|date_format:Y-m-d',
        ]);
        
        $appointments = Appointment::whereDate('date', $request->date)->get();

        return AvailableAppointmentResource::collection($appointments);
    }

    public function bookNewAppointment(Request $request) {
        // Validate the request
        $request->validate([
            'doctor_id' => 'required|exists:doctors,id',
            'date' => 'required|date|after_or_equal:today',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
        ]);

        // Step 2: Check for overlapping appointments
        $overlappingAppointments = Appointment::where('doctor_id', $request->doctor_id)
            ->where('date', $request->date)
            ->where(function ($query) use ($request) {
                $query->where('start_time', '<', $request->end_time)
                    ->where('end_time', '>', $request->start_time);
            })
            ->exists();

        if ($overlappingAppointments) {
            return response()->json([
            'message' => 'The selected time slot is not available.'
        ], 400);
        }

        $day = Carbon::parse($request->date)->format('l');

        $appointment = Appointment::create([
            'patient_id' => auth()->user()->id,
            'doctor_id' => $request->doctor_id,
            'date' => $request->date,
            'day' => $day,
            'start_time' => $request->start_time,
        'end_time' => $request->end_time
    ]);

    return response()->json([
        'message' => 'Appointment booked successfully',
        'appointment' => $appointment
    ]);
    }
}
