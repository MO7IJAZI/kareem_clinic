<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FeedbackController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'rating' => 'required|integer|min:1|max:5',
        ]);

        $feedback = Feedback::create($request->all() + ['patient_id' => auth()->user()->patient->id]);
        return response()->json([
            'message' => 'Feedback created successfully',
            'feedback' => $feedback
        ]);
    }
    public function update(Request $request, Feedback $feedback)
    {
        if ($feedback->patient_id !== auth()->user()->patient->id) {
            return response()->json([
                'message' => 'Unauthorized',
            ], 403);
        }
        
        $feedbackData = array_filter($request->all(), function($value) {
            return !is_null($value);
        });
        $feedback->update($feedbackData);
        return response()->json([
            'message' => 'Feedback updated successfully',
            'feedback' => $feedback
        ]);
    }
    public function destroy(Feedback $feedback)
    {
        if ($feedback->patient_id !== auth()->user()->patient->id) {
            return response()->json([
                'message' => 'Unauthorized',
            ], 403);
        }
        $feedback->delete();
        return response()->json([
            'message' => 'Feedback deleted successfully',
        ]);
    }
}
