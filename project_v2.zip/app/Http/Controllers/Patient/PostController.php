<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Http\Requests\PatientPostRequest;
use App\Http\Resources\Patient\PostResource;
use App\Models\Post;
use App\Services\ImageUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    protected $imageService;
    public function __construct(ImageUploadService $imageService)
    {
        $this->imageService = $imageService;
    }
    public function index()
    {
        $posts = Post::with('patient')->get();
        return PostResource::collection($posts);
    }
    public function store(PatientPostRequest $request)
    {
        $patientId = Auth::user()->patient->id;
        $postData = $request->validated();

        if ($request->hasFile('image')) {
            $postData['image'] = $this->imageService->uploadImage($request, 'image', 'posts');
        }

        $post = Post::create($postData + ['patient_id' => $patientId]);

        return response()->json([
            'message' => 'Post created successfully',
            'post' => $post
        ]);
    }
    public function show(Post $post)
    {
        $post = Post::with('patient')->find($post->id);
        $post->comments = $post->comments->map(function ($comment) {
            if ($comment->is_anonymous) {
                $comment->user->username = 'Anonymous Member';
            }
            return $comment;
        });
        
        return response()->json([
            'post' => $post
        ]);
    }
    public function update(Request $request, Post $post)
    {
        $this->authorize('update', $post);

        $postData = array_filter($request->all(), function($value) {
            return !is_null($value);
        });
        if ($request->hasFile('image')) {
            $postData['image'] = $this->imageService->uploadImage($request, 'image', 'posts');
        }

        $post->update($postData);
        return response()->json([
            'message' => 'Post updated successfully',
            'post' => $post
        ]);
    }
    public function destroy(Post $post)
    {
        $this->authorize('delete', $post);

        $post->delete();
        return response()->json([
            'message' => 'Post deleted successfully',
        ]);
    }
}
