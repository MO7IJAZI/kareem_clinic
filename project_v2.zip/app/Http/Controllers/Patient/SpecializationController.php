<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Patient\SpecializationDoctorResource;
use App\Http\Resources\Patient\SpecializationResource;
use App\Models\Specialization;
use Illuminate\Http\Request;

class SpecializationController extends Controller
{
    public function index() {
        return SpecializationResource::collection(Specialization::all());
    }
    public function getDoctors(Specialization $specialization) {
        return SpecializationDoctorResource::collection($specialization->doctors);
    }
}
