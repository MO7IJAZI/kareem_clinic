<?php

namespace App\Http\Controllers\Secretary;

use App\Http\Controllers\Controller;
use App\Http\Resources\Manager\SecretaryResource;
use Illuminate\Http\Request;
use App\Services\ImageUploadService;
class ProfileController extends Controller
{
    protected $imageService;
    public function __construct(ImageUploadService $imageService)
    {
        $this->imageService = $imageService;
    }
    public function profile() {
        $secretary = auth()->user()->secretary;
        return new SecretaryResource($secretary);
    }
    public function updateProfile(Request $request) {
        $user = auth()->user();
        $secretary = auth()->user()->secretary;
        $secretaryData = $request->all();

        /**
         * removes any key/value pair where the value is null. 
         * This prevents overwriting existing data with null.
         */
        $secretaryData = array_filter($secretaryData, function($value) {
            return !is_null($value);
        });
        
        if ($request->hasFile('image')) {
            $secretaryData['image'] = $this->imageService->uploadImage($request, 'image', 'secretaries');
        }

        $user->update($secretaryData);
        $secretary->update($secretaryData);
        
        return new SecretaryResource($secretary);
    }
}
