<?php

namespace App\Http\Controllers\Secretary;

use App\Http\Controllers\Controller;
use App\Http\Resources\Secretary\AppointmentResource;
use App\Models\Appointment;
use App\Models\Notification;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AppointmentController extends Controller
{
    public function bookNewAppointment(Request $request) {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'doctor_id' => 'required|exists:doctors,id',
            'date' => 'required|date|after_or_equal:today',
            'day' => 'required|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'status' => 'required|in:pending,confirmed,cancelled'
        ]);
        DB::beginTransaction();
        $appointment = Appointment::create([
            'patient_id' => $request->patient_id,
            'doctor_id' => $request->doctor_id,
            'date' => $request->date,
            'day' => $request->day,
            'start_time' => $request->start_time,
            'end_time' => $request->end_time,
            'status' => $request->status
        ]);
        Notification::create([
            'patient_id' => $request->patient_id,
            'type' => 'appointment',
            'message' => 'New appointment created',
        ]);
        DB::commit();
        return response()->json([
            'message' => 'Appointment created successfully and Notification sent!',
            'data' => new AppointmentResource($appointment),
        ], 201);
    }

    public function bookedAppointments() {
        return AppointmentResource::collection(Appointment::all());
    }
    
    public function newstAppointments() {
        $now = Carbon::now();
        $newestAppointments = Appointment::where('date', '>=', $now->toDateString())
            ->orderBy('date', 'asc')
            ->orderBy('start_time', 'asc')
            ->get();

        return AppointmentResource::collection($newestAppointments);
    }
}
