<?php

namespace App\Http\Controllers\Secretary;

use App\Http\Controllers\Controller;
use App\Http\Requests\PatientRegistrationRequest;
use App\Http\Resources\Secretary\PatientResource;
use App\Models\Doctor;
use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Support\Facades\DB;
class PatientController extends Controller
{
    public function registerPatient(PatientRegistrationRequest $request) {

        $validatedData = $request->validated();
        
        $user = User::create([
            'username' => $validatedData['first_name'] . ' ' . $validatedData['last_name'],
            'password' => bcrypt($validatedData['password']),
            'email' => $validatedData['email'],
            'role' => 'patient'
        ]);
        DB::beginTransaction();
        $patient = Patient::create($validatedData + ['user_id' => $user->id]);
        MedicalRecord::create([
            'patient_id' => $patient->id,
        ]);
        DB::commit();
        return response()->json([
            'message' => 'Patient registered successfully!',
            'password' => $validatedData['password']
        ], 200);
    }
    public function getAllPatients() {
        return PatientResource::collection(Patient::all());
    }
    public function getAllDoctors() {
        return Doctor::get()->map(function ($doctor) {
            return [
                'id' => $doctor->id,
                'user_name' => $doctor->user->username
            ];
        });
    }
}
