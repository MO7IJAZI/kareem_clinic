<?php

namespace App\Http\Controllers\LabTechnician;

use App\Http\Controllers\Controller;
use App\Http\Resources\LabTechnician\RequestAnalyticsResource;
use App\Models\Notification;
use App\Models\PatientLabTest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RequestAnalyticsController extends Controller
{
    public function index() {
        $labTests = PatientLabTest::with([
            'patient.user',
            'doctor.user',
            'labTest',
            'results.labTestParameter'
        ])->latest('test_date')->get();

        return RequestAnalyticsResource::collection($labTests);
    }
    public function updateStatus(Request $request, PatientLabTest $patientLabTest)
    {
        $request->validate([
            'status' => 'required|string|in:complete',
        ]);

        if ($patientLabTest->status === 'complete') {
            return response()->json(['message' => 'This lab test has already been completed.'], 409);
        }

        DB::transaction(function () use ($request, $patientLabTest) {
            $patientLabTest->update(['status' => $request->status]);

            $patientLabTest->load('doctor.user', 'patient.user', 'labTest');

            if ($patientLabTest->doctor && $patientLabTest->doctor->user) {
                Notification::create([
                    'user_id' => $patientLabTest->doctor->user->id,
                    'type' => 'lab_test_completed',
                    'message' => "The results for the lab test '{$patientLabTest->labTest->test_name}' for patient '{$patientLabTest->patient->user->name}' are ready.",
                ]);
            }
        });
        return response()->json([
            'message' => 'Lab test status updated to complete and notification sent to the doctor.'
        ]);
    }
    
    public function analytics()
    {
        $pendingTests = PatientLabTest::where('status', 'pending')
            ->with('patient.user', 'doctor.user', 'labTest')
            ->latest('test_date')
            ->get();

        return RequestAnalyticsResource::collection($pendingTests);
    }
}
