<?php

namespace App\Http\Controllers\LabTechnician;

use App\Http\Controllers\Controller;
use App\Models\LabTest;
use Illuminate\Http\Request;

class AnaylticsController extends Controller
{
    public function index() {
        $analytics = LabTest::all();
        return $analytics;
    }
    public function store(Request $request) {
        $request->validate([
            'test_name' => 'required|string',
            'description' => 'required|string',
            'price' => 'required|numeric'
        ]);
        $labTest = LabTest::create($request->all());
        return response()->json([
            'message' => 'Lab test created successfully',
            'data' => $labTest
        ]);
    }
    public function destroy(LabTest $labTest) {
        $labTest->delete();
        return response()->json([
            'message' => 'Lab test deleted successfully'
        ]);
    }
}
