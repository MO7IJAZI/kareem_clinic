<?php

namespace App\Http\Controllers\LabTechnician;

use App\Http\Controllers\Controller;
use App\Http\Resources\LabTechnician\ProfileResource;
use App\Services\ImageUploadService;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    protected $imageService;
    public function __construct(ImageUploadService $imageService)
    {
        $this->imageService = $imageService;
    }
    public function profile()
    {
        $labTechnician = auth()->user()->labTechnician;
        return new ProfileResource($labTechnician);
    }
    public function updateProfile(Request $request)
    {
        $user = auth()->user();
        $labTechnician = auth()->user()->labTechnician;
        $labTechnicianData = $request->all();

        $labTechnicianData = array_filter($labTechnicianData, function($value) {
            return !is_null($value);
        });
        if ($request->hasFile('image')) {
            $labTechnicianData['image'] = $this->imageService->uploadImage($request, 'image', 'lab_techs');
        }
        $user->update($labTechnicianData);
        $labTechnician->update($labTechnicianData);
        
        return response()->json([
            'message' => 'Profile updated successfully',
            'data' => new ProfileResource($labTechnician)
        ]);
    }
    public function changePassword(Request $request)
    {
        $request->validate([
            'current_password' => ['required', 'string'],
            'new_password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $user = auth()->user();

        // Check if the provided current password matches the stored password
        if (!Hash::check($request->current_password, $user->password)) {
            return response()->json(['message' => 'The provided password does not match your current password.'], 422);
        }

        // Hash and save the new password
        $user->password = Hash::make($request->password);
        $user->save();

        return response()->json(['message' => 'Password changed successfully']);
    }
}
