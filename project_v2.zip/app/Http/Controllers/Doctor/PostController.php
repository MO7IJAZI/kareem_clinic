<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\PostResource;
use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index() {
        return PostResource::collection(Post::latest()->get());
    }
    public function show(Post $post) {
        return new PostResource($post);
    }
}
