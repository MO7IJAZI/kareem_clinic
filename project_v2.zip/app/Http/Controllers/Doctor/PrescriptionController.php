<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\PrescriptionResource;
use App\Models\Patient;
use App\Models\Prescription;
use Illuminate\Http\Request;

class PrescriptionController extends Controller
{
    public function index(Patient $patient) {
        return PrescriptionResource::collection($patient->prescriptions()->get());
    }
    public function show(Patient $patient, Prescription $prescription) {
        //check if the prescription belongs to the patient
        if ($prescription->patient_id !== $patient->id) {
            return response()->json([
                'message' => 'this prescription does not belong to this patient',
            ], 401);
        }
        return new PrescriptionResource($prescription);
    }
    public function store(Request $request, Patient $patient) {
        $request->validate([
            'medication' => 'required|string',
            'dosage' => 'required|string',
            'frequency' => 'required|string',
            'duration' => 'required|string',
            'instructions' => 'required|string',
        ]);
        $prescription = $patient->prescriptions()->create([
            'medication' => $request->medication,
            'dosage' => $request->dosage,
            'frequency' => $request->frequency,
            'duration' => $request->duration,
            'instructions' => $request->instructions,
            'doctor_id' => auth()->user()->doctor->id,
            'medical_record_id' => $patient->medicalRecord->id,
        ]);
        return response()->json([
            'message' => 'Prescription created successfully',
            'prescription' => new PrescriptionResource($prescription),
        ]);
    }
    public function update(Request $request, Patient $patient, Prescription $prescription) {
        
        if ($prescription->patient_id !== $patient->id) {
            return response()->json([
                'message' => 'You are not authorized to update this prescription',
            ], 401);
        }

        $prescriptionData = array_filter($request->all(), function($value) {
            return !is_null($value);
        });
        $prescription->update($prescriptionData);
        return new PrescriptionResource($prescription);
    }
    public function destroy(Patient $patient, Prescription $prescription) {
        $prescription->delete();
        return response()->json([
            'message' => 'Prescription deleted successfully',
        ]);
    }
}
