<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\CommentResource;
use App\Models\Comment;
use App\Models\Post;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function index(Post $post) {
        return CommentResource::collection($post->comments()->get());
    }
    public function store(Request $request, Post $post) {
        $request->validate([
            'body' => 'required|string',
        ]);
        $comment = $post->comments()->create([
            'body' => $request->body,
            'user_id' => auth()->user()->id,
        ]);
        return response()->json([
            'message' => 'Comment created successfully',
            'comment' => new CommentResource($comment),
        ]);
    }
    public function show(Post $post, Comment $comment) {
        return new CommentResource($comment);
    }
    public function update(Request $request, Post $post, Comment $comment) {
        $request->validate([
            'body' => 'required|string',
        ]);
        if ($comment->user()->id != auth()->user()->id) {
            return response()->json([
                'message' => 'You are not authorized to update this comment',
            ], 401);
        }
        $comment->update([
            'body' => $request->body,
        ]);
        return new CommentResource($comment);
    }
    public function destroy(Post $post, Comment $comment) {
        
        if ($comment->user()->id != auth()->user()->id) {
            return response()->json([
                'message' => 'You are not authorized to delete this comment',
            ], 401);
        }
        $comment->delete();
        return response()->json([
            'message' => 'Comment deleted successfully',
        ], 200);
    }
}
