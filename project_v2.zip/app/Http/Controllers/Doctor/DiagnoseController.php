<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Diagnose;
use App\Models\MedicalRecord;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DiagnoseController extends Controller
{
    public function addDiagnosis(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'diagnosis' => 'required|string',
            'prescription' => 'required|string',
            'lab_tests_recommended' => 'required|string',
            'notes' => 'required|string',
        ]);

        $doctor = auth()->user()->doctor;
        DB::beginTransaction();
        $medicalRecord = MedicalRecord::where('patient_id', $request->patient_id)->first();
        $diagnosis = Diagnose::create([
            'doctor_id' => $doctor->id,
            'medical_record_id' => $medicalRecord->id,
            'patient_id' => $request->patient_id,
            'diagnosis' => $request->diagnosis,
            'visit_date' => now(),
            'prescription' => $request->prescription,
            'notes' => $request->notes,
            'lab_tests_recommended' => $request->lab_tests_recommended,
        ]);
        Notification::create([
            'patient_id' => $request->patient_id,
            'type' => 'diagnosis',
            'message' => 'New diagnosis created',
        ]);
        DB::commit();
        return response()->json([
            'message' => 'Diagnosis created successfully and Notification sent!',
            'data' => $diagnosis,
        ], 201);
    }
    public function getDiagnosis()
    {
        $diagnosis = Diagnose::where('doctor_id', auth()->user()->doctor->id)->get();
        return response()->json($diagnosis, 200);
    }
}
