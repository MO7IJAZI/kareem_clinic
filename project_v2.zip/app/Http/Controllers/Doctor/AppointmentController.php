<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\AppointmentResource;
use Illuminate\Http\Request;
use App\Models\Appointment;
use Carbon\Carbon;

class AppointmentController extends Controller
{
    
    public function index(Request $request)
    {
        $filter = $request->input('filter', 'daily'); // default to daily if not specified
        $now = Carbon::now();
        
        $query = Appointment::with('patient')
            ->where('doctor_id', auth()->user()->doctor->id);
            
        if ($filter === 'daily') {
            $query = $query->whereDate('date', $now->toDateString());
        } else if ($filter === 'weekly') {
            $query = $query->whereBetween('date', [
                $now->startOfWeek()->toDateString(),
                $now->endOfWeek()->toDateString()
            ]);
        }
        
        $appointments = $query->orderBy('date')
            ->orderBy('start_time')
            ->get();

        return AppointmentResource::collection($appointments);
    }

    public function filter(Request $request)
    {
        $filter = $request->input('filter');
        
        $appointments = Appointment::with('patient')
            ->where('doctor_id', auth()->user()->doctor->id);
        
        if ($filter === 'completed') {
            $appointments = $appointments->where('status', 'completed');
        } else if ($filter === 'scheduled') {
            $appointments = $appointments->where('status', 'scheduled');
        } else if ($filter === 'cancelled') {
            $appointments = $appointments->where('status', 'cancelled');
        }

        return AppointmentResource::collection($appointments->get());
    }

}
