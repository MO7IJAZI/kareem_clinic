<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\PatientResource;
use App\Models\MedicalNote;
use App\Models\Patient;
use Illuminate\Http\Request;
use Carbon\Carbon;
class PatientController extends Controller
{
    public function index()
    {
        $patients = Patient::with(
            'medicalRecord', 
            'medicalRecord.diagnoses', 
            'medicalRecord.notes', 
            'user'
        )->get();
        return PatientResource::collection($patients);
    }
    public function show(Patient $patient)
    {
        $patient = Patient::with(
            'medicalRecord', 
            'medicalRecord.diagnoses', 
            'medicalRecord.notes',
            'medicalRecord.prescriptions',
            'user'
        )->find($patient->id);
        return new PatientResource($patient);
    }
    public function store(Request $request, Patient $patient)
    {
        $request->validate([
            'note' => 'required|string',
        ]);

        $doctor = auth()->user()->doctor;

        $note = MedicalNote::create([
            'note' => $request->note,
            'medical_record_id' => $patient->medicalRecord->id,
            'doctor_id' => $doctor->id,
        ]);

        return response()->json([
            'message' => 'Note added successfully',
            'note' => $note->note,
            'created_at' => Carbon::parse($note->created_at)->format('Y-m-d H:i:s'),
        ], 201);
    }
}
