<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\NotificationResource;
use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index() {
        $doctor = auth()->user();
        $notifications = $doctor->notifications()
            ->where('read', 0)
            ->get();
        return NotificationResource::collection($notifications);
    }
    public function readNotifications() {
        $doctor = auth()->user();
        $notifications = $doctor->notifications()
            ->where('read', 1)
            ->get();
        return NotificationResource::collection($notifications);
    }
    public function markAsRead(Notification $notification) {
        
        $notification->read = 1;
        $notification->save();
        return response()->json([
            'message' => 'Notification marked as read',
        ]);
    }
    public function destroy(Notification $notification) {
        $notification->delete();
        return response()->json([
            'message' => 'Notification deleted successfully',
        ]);
    }
}
