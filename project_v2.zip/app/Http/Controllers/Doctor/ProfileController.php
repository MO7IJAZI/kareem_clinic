<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\ImageUploadService;
use App\Http\Resources\Doctor\ProfileResource;
class ProfileController extends Controller
{
    protected $imageService;

    public function __construct(ImageUploadService $imageService)
    {
        $this->imageService = $imageService;
    }

    public function profile()
    {
        $doctor = auth()->user()->doctor;
        return new ProfileResource($doctor);
    }

    public function updateProfile(Request $request) {
        $user = auth()->user();
        $doctor = auth()->user()->doctor;
        $doctorData = $request->all();

        $doctorData = array_filter($doctorData, function($value) {
            return !is_null($value);
        });
        
        if ($request->hasFile('image')) {
            $doctorData['image'] = $this->imageService->uploadImage($request, 'image', 'doctors');
        }

        $user->update($doctorData);
        $doctor->update($doctorData);
        
        return response()->json([
            'message' => 'Profile updated successfully',
            'data' => new ProfileResource($doctor)
        ]);
    }
}
