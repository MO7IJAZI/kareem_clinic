<?php

namespace App\Http\Resources\Doctor;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;
class PatientResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'username' => $this->user->username,
            'phone' => $this->phone_number,
            'address' => $this->address,
            'image' => $this->image,
            'date_of_birth' => $this->date_of_birth,
            'age' => Carbon::parse($this->date_of_birth)->age,
            'gender' => $this->gender,
            'medical_record' => [
                'id' => $this->medicalRecord->id ?? null,
                'blood_type' => $this->medicalRecord->blood_type ?? null,
                'diagnoses' => $this->medicalRecord->diagnoses ?? null,
                'notes' => $this->medicalRecord->notes ?? null,
            ],
        ];
    }
}
