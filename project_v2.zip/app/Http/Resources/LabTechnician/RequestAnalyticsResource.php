<?php

namespace App\Http\Resources\LabTechnician;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RequestAnalyticsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'patient_name' => $this->patient->user->username,
            'doctor_name' => $this->doctor->user->username,
            'lab_test_name' => $this->labTest->test_name,
            'date' => $this->test_date,
            'status' => $this->status,
            'results' => $this->results
        ];
    }
}
