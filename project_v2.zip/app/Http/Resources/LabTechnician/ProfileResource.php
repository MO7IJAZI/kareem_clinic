<?php

namespace App\Http\Resources\LabTechnician;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProfileResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'full_name' => $this->user->username,
            'email' => $this->user->email,
            'image' => $this->image ?? 'there is no image',
            'address' => $this->address ?? '',
            'phone_number' => $this->phone_number ?? '',
            'lab_name' => $this->lab_name ?? '',
        ];
    }
}
