<?php

namespace App\Http\Resources\Secretary;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PatientResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_name' => $this->user->username,
            'age' => Carbon::parse($this->date_of_birth)->age,
            'active_status' => $this->active_state == 1 ? 'active' : 'in_active'
        ];
    }
}
