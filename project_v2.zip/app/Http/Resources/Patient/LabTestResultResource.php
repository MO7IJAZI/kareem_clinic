<?php

namespace App\Http\Resources\Patient;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LabTestResultResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return $this->labTests->map(function ($test) {
            return [
                'test_id' => $test->id,
                'test_name' => $test->test_name,
                'results' => $test->parameters->map(function ($parameter) {
                    return [
                        'parameter_name' => $parameter->parameter_name,
                        'unit' => $parameter->unit,
                        'normal_range' => $parameter->normal_range,
                        'result' => $parameter->results->first()->result,
                    ];
                })
            ];
        })->toArray();
    }
}
