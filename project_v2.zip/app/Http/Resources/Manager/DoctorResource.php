<?php

namespace App\Http\Resources\Manager;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DoctorResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return  [
            'id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'username' => $this->user->username,
            'email' => $this->user->email,
            'phone' => $this->phone_number,
            'address' => $this->address,
            'image' => $this->image,
            'date_of_birth' => $this->date_of_birth,
            'age' => Carbon::parse($this->date_of_birth)->age,
            'gender' => $this->gender,
            'specialization' => $this->specialization->name,
            'active_state' => $this->active_state,
            'created_at' => $this->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
