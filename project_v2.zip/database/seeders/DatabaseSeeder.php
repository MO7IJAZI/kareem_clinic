<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        \App\Models\User::create([
            'username' => 'Zain Al-din Zidan' ,
            'email_verified_at' => now() ,
            'email' => 'zain.al-din@gmail.com',
            'password' => Hash::make('passwordSuper'),
            'remember_token' => Str::random(10),
            'role' => 'manager'
        ]);
        $this->call([SpecializationSeeder::class]);
        \App\Models\Patient::factory(20)->create();
        \App\Models\Doctor::factory(20)->create();
        \App\Models\Secretary::factory(5)->create();
        \App\Models\LabTechnician::factory(5)->create();
        \App\Models\Appointment::factory(5)->create();
        \App\Models\MedicalRecord::factory(5)->create();
        \App\Models\LabTest::factory(5)->create();
        \App\Models\PatientLabTest::factory(5)->create();
        \App\Models\LabTestParameter::factory(5)->create();
        \App\Models\LabTestResult::factory(5)->create();
        \App\Models\DoctorSchedule::factory(5)->create();
        \App\Models\Post::factory(5)->create();
        \App\Models\Comment::factory(5)->create();
        \App\Models\Feedback::factory(5)->create();
        \App\Models\MedicalNote::factory(5)->create();
        \App\Models\Diagnose::factory(5)->create();
    }
}
