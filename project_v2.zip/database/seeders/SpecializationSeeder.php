<?php

namespace Database\Seeders;

use App\Models\Specialization;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SpecializationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $specializations = [
            ['name' => 'أمراض القلب', 'description' => 'متخصص في علاج أمراض القلب والأوعية الدموية.'],
            ['name' => 'طب الأعصاب', 'description' => 'متخصص في اضطرابات الجهاز العصبي والدماغ.'],
            ['name' => 'طب العظام', 'description' => 'متخصص في أمراض العظام والمفاصل والعضلات.'],
            ['name' => 'طب الأطفال', 'description' => 'متخصص في الرعاية الصحية للأطفال والرضع.'],
            ['name' => 'الأمراض الجلدية', 'description' => 'متخصص في الأمراض والمشاكل الجلدية.'],
            ['name' => 'طب العيون', 'description' => 'متخصص في أمراض العيون والجراحة.'],
            ['name' => 'الطب النفسي', 'description' => 'متخصص في الصحة النفسية والسلوك.'],
            ['name' => 'طب الغدد الصماء', 'description' => 'متخصص في اضطرابات الغدد والهرمونات.'],
            ['name' => 'أمراض الجهاز الهضمي', 'description' => 'متخصص في مشاكل الجهاز الهضمي والكبد.'],
            ['name' => 'طب الأورام', 'description' => 'متخصص في تشخيص وعلاج السرطان.'],
        ];

        foreach ($specializations as $specialization) {
            Specialization::create($specialization);
        }
    }
}
