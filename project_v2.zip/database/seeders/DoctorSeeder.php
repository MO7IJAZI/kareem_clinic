<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Doctor;

class DoctorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $doctors = [
            'سارة أحمد',
            'أحمد محمد',
            'محمد علي',
            'فاطمة سعيد',
            'سارة خالد',
            'أحمد رضا',
        ];

        foreach ($doctors as $doctor) {
            Doctor::create([
                'name' => $doctor,
            ]);
        }
    }
}
