<?php

namespace Database\Factories;

use App\Models\LabTest;
use App\Models\Patient;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\PatientLabTest>
 */
class PatientLabTestFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'patient_id' => Patient::inRandomOrder()->value('id'),
            'doctor_id' => Patient::inRandomOrder()->value('id'),
            'lab_test_id' => LabTest::inRandomOrder()->value('id'),
            'test_date' => $this->faker->dateTimeBetween('-1 year', 'now'),
        ];
    }
}
