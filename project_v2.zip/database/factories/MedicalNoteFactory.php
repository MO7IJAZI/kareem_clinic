<?php

namespace Database\Factories;

use App\Models\MedicalRecord;
use App\Models\Doctor;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\MedicalNote>
 */
class MedicalNoteFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'note' => $this->faker->sentence,
            'medical_record_id' => MedicalRecord::inRandomOrder()->value('id'),
            'doctor_id' => Doctor::inRandomOrder()->value('id'),
        ];
    }
}
