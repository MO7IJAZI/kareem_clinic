<?php

namespace Database\Factories;

use App\Models\LabTestParameter;
use App\Models\PatientLabTest;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\LabTestResult>
 */
class LabTestResultFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'patient_lab_test_id' => PatientLabTest::inRandomOrder()->value('id'),
            'lab_test_parameter_id' => LabTestParameter::inRandomOrder()->value('id'),
            'result' => $this->faker->randomElement(['13.5', '6.5', 'negative', 'Light Yellow']),
        ];
    }
}
