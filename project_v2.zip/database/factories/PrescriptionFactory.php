<?php

namespace Database\Factories;

use App\Models\Doctor;
use App\Models\MedicalRecord;
use App\Models\Patient;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Prescription>
 */
class PrescriptionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $medications = [
            'باراسيتامول', 'باندول', 'اوغمانتين',
            'إيبوبروفين', 'أموكسيسيلين', 'لوراتادين',
            'ديكستروميثورفان', 'أوميبرازول', 'فيتامين سي',
            'أسبرين', 'ميتفورمين', 'سالبوتامول', 'سيتريزين'
        ];
        $dosages = [
            '100mg', '200mg', '300mg', '400mg', '500mg', 
            '600mg', '700mg', '800mg', '900mg',
        ];
        $frequencies = ['مرة واحدة يومياً', 'مرتين يومياً', 'ثلاث مرات يومياً', 'عند اللزوم'];
        $durations = ['3 أيام', '5 أيام', '7 أيام', '10 أيام', 'أسبوعين', 'شهر'];

        return [
            'medication' => fake()->randomElement($medications),
            'dosage' => fake()->arrayItem($dosages),
            'frequency' => fake()->randomElement($frequencies),
            'duration' => fake()->randomElement($durations),
            'instructions' => fake()->sentence(),
            'patient_id' => Patient::inRandomOrder()->first()->id,
            'doctor_id' => Doctor::inRandomOrder()->first()->id,
            'medical_record_id' => MedicalRecord::inRandomOrder()->first()->id,    
        ];
    }
}
