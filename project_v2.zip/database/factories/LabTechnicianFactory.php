<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\LabTechnician>
 */
class LabTechnicianFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory()->create(['role'=>'lab_tech'])->id,
            'image' => $this->faker->imageUrl(),
            'address' => $this->faker->address,
            'lab_name' => $this->faker->company,
            'phone_number' => $this->faker->phoneNumber,
        ];
    }
}
