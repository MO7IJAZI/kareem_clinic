<?php

namespace Database\Factories;

use App\Models\LabTest;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\LabTestParameter>
 */
class LabTestParameterFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $analytics = ['Hemoglobin', 'White Blood Cells', 'Protein', 'Glucose'];
        return [
            'lab_test_id' => LabTest::inRandomOrder()->value('id'),
            'parameter_name' => $this->faker->randomElement($analytics),
            'unit' => $this->faker->randomElement(['g/dL', 'x10^9/L', 'mg/dL']),
            'normal_range' => $this->faker->randomElement(['13.5-17.5 g/dL', '4.0-11.0 x10^9/L']),
        ];
    }
}
