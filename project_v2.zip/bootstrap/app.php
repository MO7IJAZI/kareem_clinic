<?php

use App\Http\Middleware\DoctorMiddleware;
use App\Http\Middleware\LabTechMiddleware;
use App\Http\Middleware\ManagerMiddleware;
use App\Http\Middleware\PatientMiddleware;
use App\Http\Middleware\SecretaryMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Middleware\HandleCors;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )

    ->withMiddleware(function (Middleware $middleware) {
        $middleware->use([
            HandleCors::class
        ]);
        
        $middleware->validateCsrfTokens(except: [
            '/*',
        ]);
        $middleware->alias([
            'patient' => PatientMiddleware::class,
            'doctor' => DoctorMiddleware::class,
            'manager' => ManagerMiddleware::class,
            'secretary' => SecretaryMiddleware::class,
            'labTechnician' => LabTechMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
