<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\Patient\AppointmentController;
use App\Http\Controllers\Patient\AuthController;
use App\Http\Controllers\Patient\LabTestController;
use App\Http\Controllers\Patient\ProfileController;
use App\Http\Controllers\Patient\PostController;
use App\Http\Controllers\Patient\CommentController;
use App\Http\Controllers\Patient\FeedbackController;
use App\Http\Controllers\Patient\SpecializationController;
use App\Http\Controllers\Manager\AuthController as ManagerAuthController;
use App\Http\Controllers\Manager\FeedbackController as ManagerFeedbackController;
use App\Http\Controllers\Manager\SpecializationController as ManagerSpecializationController;
use App\Http\Controllers\Manager\DoctorController as ManagerDoctorController;
use App\Http\Controllers\Manager\LabController;
use App\Http\Controllers\Manager\ReportController;
use App\Http\Controllers\Manager\SecretaryController;
use App\Http\Controllers\Doctor\DiagnoseController;
use App\Http\Controllers\Doctor\PatientController as DoctorPatientController;
use App\Http\Controllers\Doctor\ProfileController as DoctorProfileController;
use App\Http\Controllers\Doctor\AppointmentController as DocotorAppointmentController;
use App\Http\Controllers\Doctor\CommentController as DoctorCommentController;
use App\Http\Controllers\Doctor\NotificationController as DoctorNotificationController;
use App\Http\Controllers\Doctor\PostController as DoctorPostController;
use App\Http\Controllers\Doctor\PrescriptionController;
use App\Http\Controllers\LabTechnician\AnaylticsController;
use App\Http\Controllers\Patient\NotificationController;
use App\Http\Controllers\Secretary\AppointmentController as SecretaryAppointmentController;
use App\Http\Controllers\Secretary\PatientController;
use App\Http\Controllers\Secretary\ProfileController as SecretaryProfileController;
use App\Http\Controllers\LabTechnician\ProfileController as LabTechnicianProfileController;
use App\Http\Controllers\LabTechnician\RequestAnalyticsController;
use Illuminate\Support\Facades\Route;

Route::post('login', [LoginController::class, 'login'])->middleware(['throttle:10,1']);
Route::post('patient-register', [AuthController::class, 'register']);

Route::group(['prefix' => 'manager', 'middleware' => ['auth:sanctum','manager']], function () {
    Route::group(['prefix' => 'register'], function () {
        Route::post('secretary', [ManagerAuthController::class, 'registerNewSecretary']);
        Route::post('doctor', [ManagerAuthController::class, 'registerNewDoctor']);
        Route::post('lab-technician', [ManagerAuthController::class, 'registerNewLabTechnician']);
    });
    Route::group(['prefix' => 'specializations'], function () {
        Route::get('/', [ManagerSpecializationController::class, 'index']);
        Route::post('create', [ManagerSpecializationController::class, 'store']);
        Route::post('{specialization}', [ManagerSpecializationController::class, 'update']);
        Route::delete('{specialization}', [ManagerSpecializationController::class, 'destroy']);
        Route::post('{specialization}/lab-technicians', [ManagerSpecializationController::class, 'addLabTechnicianToSpecialization']);
        Route::delete('{specialization}/lab-technicians/{labTechnician}', [ManagerSpecializationController::class, 'removeLabTechnicianFromSpecialization']);
    });
    Route::group(['prefix' => 'doctors'], function () {
        Route::get('/', [ManagerDoctorController::class, 'index']);
        Route::delete('{doctor}', [ManagerDoctorController::class, 'destroy']);
        Route::post('{doctor}/specializations/{specialization}', [ManagerDoctorController::class, 'addDoctorToSpecialization']);
        Route::delete('{doctor}/specializations/{specialization}', [ManagerDoctorController::class, 'removeDoctorFromSpecialization']);
    });
    Route::group(['prefix' => 'lab-tests'], function () {
        Route::get('/', [LabController::class, 'index']);
        Route::get('/lab-technicians', [LabController::class, 'displayLabTechnicians']);
        Route::post('create', [LabController::class, 'store']);
        Route::post('{labTest}', [LabController::class, 'update']);
        Route::delete('{labTest}', [LabController::class, 'destroy']);
    });
    Route::group(['prefix' => 'reports'], function () {
        Route::get('/daily', [ReportController::class, 'dailyReport']);
        Route::get('/monthly', [ReportController::class, 'monthlyReport']);
    });
    Route::get('secretaries', [SecretaryController::class, 'index']);
    Route::get('feedbacks', [ManagerFeedbackController::class, 'getAllFeedbacks']);
});

Route::group(['prefix' => 'secretary', 'middleware' => ['auth:sanctum','secretary']], function () {
    Route::get('patients', [PatientController::class, 'getAllPatients']);
    Route::get('doctors', [PatientController::class, 'getAllDoctors']);
    Route::post('new-patient', [PatientController::class, 'registerPatient']);
    
    Route::group(['prefix' => 'appointments'], function () {
        Route::get('booked-appointments', [SecretaryAppointmentController::class, 'bookedAppointments']);
        Route::get('newst-appointments', [SecretaryAppointmentController::class, 'newstAppointments']);
        Route::post('book', [SecretaryAppointmentController::class, 'bookNewAppointment']);
    });
    Route::group(['prefix' => 'profile'], function () {
        Route::get('/', [SecretaryProfileController::class, 'profile']);
        Route::post('update', [SecretaryProfileController::class, 'updateProfile']);
    });
    
    Route::post('logout', [AuthController::class, 'logout']);
});

Route::group(['prefix' => 'patient', 'middleware' => ['auth:sanctum','patient']], function () {
    Route::group(['prefix' => 'profile'], function () {
        Route::get('/', [ProfileController::class, 'profile']);
        Route::post('update', [ProfileController::class, 'updateProfile']);
    });
    Route::group(['prefix' => 'specializations'], function () {
        Route::get('/', [SpecializationController::class, 'index']);
        Route::get('/{specialization}/doctors', [SpecializationController::class, 'getDoctors']);
    });
    Route::group(['prefix' => 'appointments'], function () {
        Route::get('my-appointments', [AppointmentController::class, 'myAppointments']);
        Route::post('available', [AppointmentController::class, 'getAvailableAppointments']);
        Route::post('new-appointment', [AppointmentController::class, 'bookNewAppointment']);
    });
    Route::group(['prefix' => 'lab_tests'], function () {
        Route::get('/', [LabTestController::class, 'index']);
    });
    Route::group(['prefix' => 'posts'], function () {
        Route::get('/', [PostController::class, 'index']);
        Route::get('/{post}', [PostController::class, 'show']);
        Route::post('create', [PostController::class, 'store']);
        Route::post('/{post}', [PostController::class, 'update']);
        Route::delete('/{post}', [PostController::class, 'destroy']);
    });
    Route::group(['prefix' => 'posts/{post}/comments'], function () {
        Route::get('/', [CommentController::class, 'index']);
        Route::get('/{comment}', [CommentController::class, 'show']);
        Route::post('create', [CommentController::class, 'store']);
        Route::post('/{comment}', [CommentController::class, 'update']);
        Route::delete('/{comment}', [CommentController::class, 'destroy']);
    });
    Route::group(['prefix' => 'feedbacks'], function () {
        Route::post('create', [FeedbackController::class, 'store']);
        Route::post('/{feedback}', [FeedbackController::class, 'update']);
        Route::delete('/{feedback}', [FeedbackController::class, 'destroy']);
    });
    Route::group(['prefix' => 'notifications'], function () {
        Route::get('/', [NotificationController::class, 'index']);
        Route::get('/read', [NotificationController::class, 'readNotifications']);
        Route::post('/{notification}/read', [NotificationController::class, 'markAsRead']);
        Route::delete('/{notification}', [NotificationController::class, 'destroy']);
    });
    Route::post('logout', [AuthController::class, 'logout']);
});

Route::group(['prefix' => 'doctor', 'middleware' => ['auth:sanctum','doctor']], function () {
    Route::group(['prefix' => 'profile'], function () {
        Route::get('/', [DoctorProfileController::class, 'profile']);
        Route::post('update', [DoctorProfileController::class, 'updateProfile']);
    });
    Route::group(['prefix' => 'diagnosis'], function () {
        Route::post('add', [DiagnoseController::class, 'addDiagnosis']);
        Route::get('get', [DiagnoseController::class, 'getDiagnosis']);
    });
    Route::group(['prefix' => 'appointments'], function () {
        Route::get('/', [DocotorAppointmentController::class, 'index']);
        Route::post('filter-status', [DocotorAppointmentController::class, 'filter']);
    });
    Route::group(['prefix' => 'prescriptions'], function () {
        Route::get('/', [PrescriptionController::class, 'index']);
        Route::get('{prescription}', [PrescriptionController::class, 'show']);
        Route::post('create', [PrescriptionController::class, 'store']);
        Route::post('{prescription}', [PrescriptionController::class, 'update']);
        Route::delete('{prescription}', [PrescriptionController::class, 'destroy']);
    });
    
    Route::group(['prefix' => 'patients'], function () {
        Route::get('/', [DoctorPatientController::class, 'index']);
        Route::get('/{patient}/medical-record', [DoctorPatientController::class, 'show']);
        Route::post('/{patient}/add-note', [DoctorPatientController::class, 'store']);
    });
    Route::group(['prefix' => 'posts'], function () {
        Route::get('/', [DoctorPostController::class, 'index']);
        Route::get('/{post}', [DoctorPostController::class, 'show']);
    });
    Route::group(['prefix' => 'posts/{post}/comments'], function () {
        Route::get('/', [DoctorCommentController::class, 'index']);
        Route::get('/{comment}', [DoctorCommentController::class, 'show']);
        Route::post('create', [DoctorCommentController::class, 'store']);
        Route::post('/{comment}', [DoctorCommentController::class, 'update']);
        Route::delete('/{comment}', [DoctorCommentController::class, 'destroy']);
    });
    Route::group(['prefix' => 'notifications'], function () {
        Route::get('/', [DoctorNotificationController::class, 'index']);
        Route::get('/read', [DoctorNotificationController::class, 'readNotifications']);
        Route::post('/{notification}/read', [DoctorNotificationController::class, 'markAsRead']);
        Route::delete('/{notification}', [DoctorNotificationController::class, 'destroy']);
    });

    Route::post('logout', [AuthController::class, 'logout']);
});

Route::group(['prefix' => 'lab-techinician', 'middleware' => ['auth:sanctum','labTechnician']], function () {
    Route::group(['prefix' => 'profile'], function () {
        Route::get('/', [LabTechnicianProfileController::class, 'profile']);
        Route::post('update', [LabTechnicianProfileController::class, 'updateProfile']);
        Route::post('change-password', [LabTechnicianProfileController::class, 'changePassword']);
    });
    Route::group(['prefix' => 'lab-requests'], function () {
        Route::get('/', [RequestAnalyticsController::class, 'index']);
        Route::post('{patientLabTest}/update-status', [RequestAnalyticsController::class, 'updateStatus']);
    });
    Route::group(['prefix' => 'analytics'], function () {
        Route::get('/', [AnaylticsController::class, 'index']);
        Route::post('/', [AnaylticsController::class, 'store']);
        Route::delete('{labTest}', [AnaylticsController::class, 'destroy']);
    });
    
});